# SWI Security Self-Check Pilot

Upload these folders into the root of `SWI-V1-Module-1-10`.

## Placement

```text
SWI-V1-Module-1-10/
├── security/
│   └── self_check.py
└── tests/
    └── test_self_check.py
```

This is a small pilot for the "security inside security" principle:
each module should validate its own conditions before processing and validate
its result before passing it onward.

The shared helper uses fail-closed semantics: a mandatory failed check stops
the validation rather than being outvoted by passing checks.

This package does not yet modify the existing Module 00–10 implementations.
Integrate it into the pilot module only after reviewing the existing API and
tests.
